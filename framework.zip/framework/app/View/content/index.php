	<main>
	<?php

		foreach ( $resultSet as $idx => $value ) {
			echo "$idx = $value";
		}
	?>
	</main>